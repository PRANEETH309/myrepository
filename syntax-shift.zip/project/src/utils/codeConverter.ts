export const convertToPython = (cCode: string): string => {
  let pythonCode = '# Python equivalent code\n\n';
  const lines = cCode.split('\n');
  let indentLevel = 0;
  
  const handlePrintf = (line: string): string => {
    const printfRegex = /printf\s*\("([^"]*)"(?:,\s*([^)]+))?\)/;
    const match = line.match(printfRegex);
    
    if (match) {
      const [_, format, args] = match;
      if (!args) {
        return `print("${format}")`;
      }
      const formatArgs = args.split(',').map(arg => arg.trim());
      const formattedString = format
        .replace(/%d/g, '')
        .replace(/%f/g, '')
        .replace(/%s/g, '')
        .replace(/%c/g, '');
      
      return `print("${formattedString}",${formatArgs.join(', ')})`;
    }
    return line;
  };

  const handleScanf = (line: string): string => {
    const scanfRegex = /scanf\s*\("([^"]+)",\s*&([^)]+)\)/;
    const match = line.match(scanfRegex);
    
    if (match) {
      const [_, format, vars] = match;
      const variable = vars.trim().replace('&', '');
      if (format.includes('%d')) {
        return `${variable} = int(input())`;
      } else if (format.includes('%f')) {
        return `${variable} = float(input())`;
      } else {
        return `${variable} = input()`;
      }
    }
    return line;
  };

  const handleConditionals = (line: string): string => {
    // Handle if statements
    const ifRegex = /if\s*\((.*)\)\s*{?/;
    const elseIfRegex = /else\s+if\s*\((.*)\)\s*{?/;
    const elseRegex = /else\s*{?/;
    
    if (line.match(elseIfRegex)) {
      const match = line.match(elseIfRegex);
      const condition = match![1]
        .replace(/&&/g, ' and ')
        .replace(/\|\|/g, ' or ')
        .replace(/!=/g, ' != ')
        .replace(/==/g, ' == ');
      return `elif ${condition}:`;
    } else if (line.match(ifRegex)) {
      const match = line.match(ifRegex);
      const condition = match![1]
        .replace(/&&/g, ' and ')
        .replace(/\|\|/g, ' or ')
        .replace(/!=/g, ' != ')
        .replace(/==/g, ' == ');
      return `if ${condition}:`;
    } else if (line.match(elseRegex)) {
      return 'else:';
    }
    
    // Handle while loops
    const whileRegex = /while\s*\((.*)\)\s*{?/;
    if (line.match(whileRegex)) {
      const match = line.match(whileRegex);
      const condition = match![1]
        .replace(/&&/g, ' and ')
        .replace(/\|\|/g, ' or ')
        .replace(/!=/g, ' != ')
        .replace(/==/g, ' == ');
      return `while ${condition}:`;
    }
    
    // Handle for loops with enhanced complexity
    const forRegex = /for\s*\((.*);(.*);(.*)\)\s*{?/;
    if (line.match(forRegex)) {
      const match = line.match(forRegex);
      if (!match) return line;
      
      const [_, init, cond, incr] = match;
      
      // Extract variable name and initial value with type handling
      const initMatch = init.trim().match(/(int|float|double|char)?\s*(\w+)\s*=\s*([^;]+)/);
      if (!initMatch) return line;
      
      const variable = initMatch[2];
      const startValue = initMatch[3].trim();
      
      // Extract end condition with complex operators
      const condMatch = cond.trim().match(/(\w+)\s*([<>]=?|==|!=)\s*([^;]+)/);
      if (!condMatch) return line;
      
      const endValue = condMatch[3].trim();
      const operator = condMatch[2];
      
      // Extract step value with complex increment/decrement
      let step = '1';
      const incrMatch = incr.trim().match(/(\w+)\s*([\+\-]=|[\+\-]{2})\s*([^;]*)/);
      if (incrMatch) {
        const operation = incrMatch[2];
        const stepValue = incrMatch[3] ? incrMatch[3].trim() : '1';
        
        if (operation === '+=' || operation === '++') {
          step = stepValue === '' ? '1' : stepValue;
        } else if (operation === '-=' || operation === '--') {
          step = stepValue === '' ? '-1' : `-${stepValue}`;
        }
      }
      
      // Handle different loop patterns
      if (operator === '<') {
        return `for ${variable} in range(${startValue}, ${endValue}, ${step}):`;
      } else if (operator === '<=') {
        return `for ${variable} in range(${startValue}, int(${endValue}) + 1, ${step}):`;
      } else if (operator === '>') {
        return `for ${variable} in range(${startValue}, ${endValue}, -${Math.abs(parseInt(step))}):`;
      } else if (operator === '>=') {
        return `for ${variable} in range(${startValue}, int(${endValue}) - 1, -${Math.abs(parseInt(step))}):`;
      } else if (operator === '!=') {
        // For loops with inequality need a while loop in Python
        return `${variable} = ${startValue}\nwhile ${variable} != ${endValue}:`;
      }
    }
    
    return line;
  };

  const handleVariableDeclaration = (line: string): string => {
    // Handle variable declarations with initialization
    if (line.match(/(int|float|double|char)\s+(\w+)\s*=\s*([^;]+);/)) {
      const match = line.match(/(int|float|double|char)\s+(\w+)\s*=\s*([^;]+);/);
      const type = match![1];
      const variable = match![2];
      const value = match![3];
      
      if (type === 'int') {
        return `${variable} = int(${value})`;
      } else if (type === 'float' || type === 'double') {
        return `${variable} = float(${value})`;
      } else {
        return `${variable} = ${value}`;
      }
    }
    
    // Skip variable declarations without initialization
    if (line.match(/(int|float|double|char)\s+([^=;]+);/)) {
      return '';
    }
    
    return line;
  };

  for (let line of lines) {
    line = line.trim();
    
    // Skip C-specific lines
    if (line.startsWith('#include') || line.includes('main()') || !line) {
      continue;
    }

    // Handle closing braces
    if (line === '}') {
      indentLevel = Math.max(0, indentLevel - 1);
      continue;
    }

    // Handle different types of statements
    line = handlePrintf(line);
    line = handleScanf(line);
    line = handleConditionals(line);
    line = handleVariableDeclaration(line);
    
    // Remove semicolons and braces
    line = line.replace(/;/g, '').replace(/{/g, '');
    
    if (line) {
      // Handle the case where we need to add multiple lines (like in the != for loop case)
      if (line.includes('\n')) {
        const subLines = line.split('\n');
        for (const subLine of subLines) {
          pythonCode += '    '.repeat(indentLevel) + subLine + '\n';
          if (subLine.endsWith(':')) {
            indentLevel++;
          }
        }
      } else {
        pythonCode += '    '.repeat(indentLevel) + line + '\n';
        if (line.endsWith(':')) {
          indentLevel++;
        }
      }
    }
  }

  return pythonCode;
};

export const convertToShell = (cCode: string): string => {
  let shellCode = '#!/bin/bash\n\n';
  let indentLevel = 0;
  
  const handlePrintf = (line: string): string => {
    const printfRegex = /printf\s*\("([^"]*)"(?:,\s*([^)]+))?\)/;
    const match = line.match(printfRegex);
    
    if (match) {
      const [_, format, args] = match;
      if (!args) {
        return `echo "${format}"`;
      }
      return `printf "${format}" ${args}`;
    }
    return line;
  };

  const handleScanf = (line: string): string => {
    const scanfRegex = /scanf\s*\("([^"]+)",\s*&([^)]+)\)/;
    const match = line.match(scanfRegex);
    
    if (match) {
      const [_, format, vars] = match;
      const variable = vars.trim().replace('&', '');
      return `read ${variable}`;
    }
    return line;
  };

  const handleConditionals = (line: string): string => {
    // Handle if statements
    const ifRegex = /if\s*\((.*)\)\s*{?/;
    const elseIfRegex = /else\s+if\s*\((.*)\)\s*{?/;
    const elseRegex = /else\s*{?/;
    
    if (line.match(elseIfRegex)) {
      const match = line.match(elseIfRegex);
      const condition = match![1]
        .replace(/&&/g, ' -a ')
        .replace(/\|\|/g, ' -o ')
        .replace(/!=/g, ' -ne ')
        .replace(/==/g, ' -eq ');
      return `elif [ ${condition} ]; then`;
    } else if (line.match(ifRegex)) {
      const match = line.match(ifRegex);
      const condition = match![1]
        .replace(/&&/g, ' -a ')
        .replace(/\|\|/g, ' -o ')
        .replace(/!=/g, ' -ne ')
        .replace(/==/g, ' -eq ');
      return `if [ ${condition} ]; then`;
    } else if (line.match(elseRegex)) {
      return 'else';
    }
    
    // Handle while loops
    const whileRegex = /while\s*\((.*)\)\s*{?/;
    if (line.match(whileRegex)) {
      const match = line.match(whileRegex);
      const condition = match![1]
        .replace(/&&/g, ' -a ')
        .replace(/\|\|/g, ' -o ')
        .replace(/!=/g, ' -ne ')
        .replace(/==/g, ' -eq ');
      return `while [ ${condition} ]; do`;
    }
    
    // Handle enhanced for loops
    const forRegex = /for\s*\((.*);(.*);(.*)\)\s*{?/;
    if (line.match(forRegex)) {
      const match = line.match(forRegex);
      if (!match) return line;
      
      const [_, init, cond, incr] = match;
      
      // Extract variable name and initial value with type handling
      const initMatch = init.trim().match(/(int|float|double|char)?\s*(\w+)\s*=\s*([^;]+)/);
      if (!initMatch) return line;
      
      const variable = initMatch[2];
      const startValue = initMatch[3].trim();
      
      // Extract end condition with complex operators
      const condMatch = cond.trim().match(/(\w+)\s*([<>]=?|==|!=)\s*([^;]+)/);
      if (!condMatch) return line;
      
      const endValue = condMatch[3].trim();
      const operator = condMatch[2];
      
      // Extract step value with complex increment/decrement
      let step = '1';
      const incrMatch = incr.trim().match(/(\w+)\s*([\+\-]=|[\+\-]{2})\s*([^;]*)/);
      if (incrMatch) {
        const operation = incrMatch[2];
        const stepValue = incrMatch[3] ? incrMatch[3].trim() : '1';
        
        if (operation === '+=' || operation === '++') {
          step = stepValue === '' ? '1' : stepValue;
        } else if (operation === '-=' || operation === '--') {
          step = stepValue === '' ? '1' : stepValue;
          step = `-${step}`;
        }
      }
      
      // Handle different loop patterns
      if (operator === '<') {
        return `for ((${variable}=${startValue}; ${variable}<${endValue}; ${variable}=${variable}+${step})); do`;
      } else if (operator === '<=') {
        return `for ((${variable}=${startValue}; ${variable}<=${endValue}; ${variable}=${variable}+${step})); do`;
      } else if (operator === '>') {
        return `for ((${variable}=${startValue}; ${variable}>${endValue}; ${variable}=${variable}${step})); do`;
      } else if (operator === '>=') {
        return `for ((${variable}=${startValue}; ${variable}>=${endValue}; ${variable}=${variable}${step})); do`;
      } else if (operator === '!=') {
        return `${variable}=${startValue}\nwhile [ $${variable} -ne ${endValue} ]; do`;
      }
    }
    
    return line;
  };

  const handleVariableDeclaration = (line: string): string => {
    // Handle variable declarations with initialization
    if (line.match(/(int|float|double|char)\s+(\w+)\s*=\s*([^;]+);/)) {
      return line.replace(/(int|float|double|char)\s+(\w+)\s*=\s*([^;]+);/, '$2=$3');
    }
    
    // Skip variable declarations without initialization
    if (line.match(/(int|float|double|char)\s+([^=;]+);/)) {
      return '';
    }
    
    return line;
  };

  const lines = cCode.split('\n');
  for (let line of lines) {
    line = line.trim();
    
    // Skip C-specific lines
    if (line.startsWith('#include') || line.includes('main()') || !line) {
      continue;
    }

    // Handle closing braces
    if (line === '}') {
      indentLevel = Math.max(0, indentLevel - 1);
      if (shellCode.trim().endsWith('do')) {
        shellCode += '    '.repeat(indentLevel) + 'done\n';
      } else if (shellCode.trim().endsWith('then') || shellCode.trim().endsWith('else')) {
        shellCode += '    '.repeat(indentLevel) + 'fi\n';
      }
      continue;
    }

    // Handle different types of statements
    line = handlePrintf(line);
    line = handleScanf(line);
    line = handleConditionals(line);
    line = handleVariableDeclaration(line);
    
    // Remove semicolons and braces
    line = line.replace(/;/g, '').replace(/{/g, '');
    
    if (line) {
      // Handle the case where we need to add multiple lines (like in the != for loop case)
      if (line.includes('\n')) {
        const subLines = line.split('\n');
        for (const subLine of subLines) {
          shellCode += '    '.repeat(indentLevel) + subLine + '\n';
          if (subLine.includes('then') || subLine.includes('do') || subLine === 'else') {
            indentLevel++;
          }
        }
      } else {
        shellCode += '    '.repeat(indentLevel) + line + '\n';
        if (line.includes('then') || line.includes('do') || line === 'else') {
          indentLevel++;
        }
      }
    }
  }

  return shellCode;
};

export const convertToJava = (cCode: string): string => {
  let javaCode = '// Java equivalent code\n\n';
  let indentLevel = 1;
  
  const handlePrintf = (line: string): string => {
    const printfRegex = /printf\s*\("([^"]*)"(?:,\s*([^)]+))?\)/;
    const match = line.match(printfRegex);
    
    if (match) {
      const [_, format, args] = match;
      if (!args) {
        return `System.out.println("${format}");`;
      }
      const formatArgs = args.split(',').map(arg => arg.trim());
      const formattedString = format
        .replace(/%d/g, '')
        .replace(/%f/g, '')
        .replace(/%s/g, '')
        .replace(/%c/g, '');
      
      return `System.out.println("${formattedString}"+ ${formatArgs.join(', ')});`;
    }
    return line;
  };

  const handleScanf = (line: string): string => {
    const scanfRegex = /scanf\s*\("([^"]+)",\s*&([^)]+)\)/;
    const match = line.match(scanfRegex);
    
    if (match) {
      const [_, format, vars] = match;
      const variable = vars.trim().replace('&', '');
      
      if (format.includes('%d')) {
        return `${variable} = scanner.nextInt();`;
      } else if (format.includes('%f')) {
        return `${variable} = scanner.nextFloat();`;
      } else if (format.includes('%c')) {
        return `${variable} = scanner.next().charAt(0);`;
      } else {
        return `${variable} = scanner.nextLine();`;
      }
    }
    return line;
  };

  const handleConditionals = (line: string): string => {
    // Handle if statements
    const ifRegex = /if\s*\((.*)\)\s*{?/;
    const elseIfRegex = /else\s+if\s*\((.*)\)\s*{?/;
    const elseRegex = /else\s*{?/;
    
    if (line.match(elseIfRegex)) {
      const match = line.match(elseIfRegex);
      return `else if (${match![1]}) {`;
    } else if (line.match(ifRegex)) {
      const match = line.match(ifRegex);
      return `if (${match![1]}) {`;
    } else if (line.match(elseRegex)) {
      return 'else {';
    }
    
    // Handle while loops
    const whileRegex = /while\s*\((.*)\)\s*{?/;
    if (line.match(whileRegex)) {
      const match = line.match(whileRegex);
      return `while (${match![1]}) {`;
    }
    
    // Handle for loops
    const forRegex = /for\s*\((.*);(.*);(.*)\)\s*{?/;
    if (line.match(forRegex)) {
      const match = line.match(forRegex);
      const [_, init, cond, incr] = match!;
      return `for (${init}; ${cond}; ${incr}) {`;
    }
    
    return line;
  };

  const handleVariableDeclaration = (line: string): string => {
    // Handle variable declarations with initialization
    if (line.match(/(int|float|double|char)\s+(\w+)\s*=\s*([^;]+);/)) {
      return line;
    }
    
    // Handle variable declarations without initialization
    if (line.match(/(int|float|double|char)\s+([^=;]+);/)) {
      return line;
    }
    
    return line;
  };

  const lines = cCode.split('\n');
  let processedLines: string[] = [];
  
  // Add class declaration and scanner
  processedLines.push('public class Main {');
  processedLines.push('    private static final java.util.Scanner scanner = new java.util.Scanner(System.in);');
  processedLines.push('');
  processedLines.push('    public static void main(String[] args) ');
  
  for (let line of lines) {
    line = line.trim();
    
    // Skip C-specific lines and empty lines
    if (line.startsWith('#include') || line.includes('main()') || !line) {
      continue;
    }

    // Handle closing braces
    if (line === '}') {
      indentLevel = Math.max(1, indentLevel - 1);
      processedLines.push('    '.repeat(indentLevel) + '}');
      continue;
    }

    // Handle different types of statements
    line = handlePrintf(line);
    line = handleScanf(line);
    line = handleConditionals(line);
    line = handleVariableDeclaration(line);
    
    // Add semicolon if missing
    if (!line.endsWith(';') && !line.endsWith('{')) {
      line += ';';
    }
    
    if (line) {
      processedLines.push('    '.repeat(indentLevel) + line);
      
      // Adjust indent level based on control structures
      if (line.endsWith('{')) {
        indentLevel++;
      }
    }
  }
  
  // Close main method and class
  processedLines.push('    ');
  processedLines.push('}');

  javaCode += processedLines.join('\n');
  return javaCode;
};