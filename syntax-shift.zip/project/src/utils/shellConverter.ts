export const convertToShell = (cCode: string): string => {
  let shellCode = '#!/bin/bash\n\n';
  let indentLevel = 0;
  
  const handlePrintf = (line: string): string => {
    const printfRegex = /printf\s*\("([^"]*)"(?:,\s*([^)]+))?\)/;
    const match = line.match(printfRegex);
    
    if (match) {
      const [_, format, args] = match;
      if (!args) {
        return `echo "${format}"`;
      }
      return `echo "${format}" ${args}`;
    }
    return line;
  };

  const handleScanf = (line: string): string => {
    const scanfRegex = /scanf\s*\("([^"]+)",\s*&([^)]+)\)/;
    const match = line.match(scanfRegex);
    
    if (match) {
      const [_, format, vars] = match;
      const variable = vars.trim().replace('&', '');
      return `read ${variable}`;
    }
    return line;
  };

  const handleConditionals = (line: string): string => {
    // Handle if statements
    const ifRegex = /if\s*\((.*)\)\s*{?/;
    const elseIfRegex = /else\s+if\s*\((.*)\)\s*{?/;
    const elseRegex = /else\s*{?/;
    
    if (line.match(elseIfRegex)) {
      const match = line.match(elseIfRegex);
      const condition = match![1]
        .replace(/&&/g, ' -a ')
        .replace(/\|\|/g, ' -o ')
        .replace(/!=/g, ' -ne ')
        .replace(/==/g, ' -eq ');
      return `elif [ ${condition} ]; then`;
    } else if (line.match(ifRegex)) {
      const match = line.match(ifRegex);
      const condition = match![1]
        .replace(/&&/g, ' -a ')
        .replace(/\|\|/g, ' -o ')
        .replace(/!=/g, ' -ne ')
        .replace(/>/g, ' -gt ')
        .replace(/==/g, ' -eq ');
      return `if [ ${condition} ]; then`;
    } else if (line.match(elseRegex)) {
      return 'else';
    }
    
    // Handle while loops
    const whileRegex = /while\s*\((.*)\)\s*{?/;
    if (line.match(whileRegex)) {
      const match = line.match(whileRegex);
      const condition = match![1]
        .replace(/&&/g, ' -a ')
        .replace(/\|\|/g, ' -o ')
        .replace(/!=/g, ' -ne ')
        .replace(/==/g, ' -eq ');
      return `while [ ${condition} ]; do`;
    }
    
    // Handle for loops
    const forRegex = /for\s*\((.*);(.*);(.*)\)\s*{?/;
    if (line.match(forRegex)) {
      const match = line.match(forRegex);
      const [_, init, cond, incr] = match!;
      
      // Extract loop variables and bounds
      const initParts = init.trim().split('=');
      const variable = initParts[0].trim().split(' ').pop()!;
      const startValue = parseInt(initParts[1]);
      
      // Extract end condition
      const condParts = cond.trim().split(/[<>]=?/);
      const endValue = parseInt(condParts[1]);
      
      // Extract step value from increment
      const stepMatch = incr.trim().match(/([+-]=|\+\+|--)/);
      let step = 1;
      if (stepMatch) {
        if (stepMatch[1] === '--' || stepMatch[1] === '-=') {
          step = -1;
        } else if (stepMatch[1] === '+=') {
          const stepValue = parseInt(incr.split('+=')[1]);
          step = stepValue || 1;
        }
      }
      
      // Create shell for loop
      if (step === 1) {
        return `for ${variable} in $(seq ${startValue} ${endValue}); do`;
      } else if (step === -1) {
        return `for ${variable} in $(seq ${startValue} -1 ${endValue}); do`;
      } else {
        return `for ${variable} in $(seq ${startValue} ${step} ${endValue}); do`;
      }
    }
    
    return line;
  };

  const handleVariableDeclaration = (line: string): string => {
    // Handle variable declarations with initialization
    if (line.match(/(int|float|double|char)\s+(\w+)\s*=\s*([^;]+);/)) {
      return line.replace(/(int|float|double|char)\s+(\w+)\s*=\s*([^;]+);/, '$2=$3');
    }
    
    // Skip variable declarations without initialization
    if (line.match(/(int|float|double|char)\s+([^=;]+);/)) {
      return '';
    }
    
    return line;
  };

  const lines = cCode.split('\n');
  for (let line of lines) {
    line = line.trim();
    
    // Skip C-specific lines
    if (line.startsWith('#include') || line.includes('main()') || !line) {
      continue;
    }

    // Handle closing braces
    if (line === '}') {
      indentLevel = Math.max(0, indentLevel - 1);
      if (shellCode.trim().endsWith('do')) {
        shellCode += '    '.repeat(indentLevel) + 'done\n';
      } else if (shellCode.trim().endsWith('then') || shellCode.trim().endsWith('else')) {
        shellCode += '    '.repeat(indentLevel) + 'fi\n';
      }
      continue;
    }

    // Handle different types of statements
    line = handlePrintf(line);
    line = handleScanf(line);
    line = handleConditionals(line);
    line = handleVariableDeclaration(line);
    
    // Remove semicolons and braces
    line = line.replace(/;/g, '').replace(/{/g, '');
    
    if (line) {
      shellCode += '    '.repeat(indentLevel) + line + '\n';
      
      // Adjust indent level based on control structures
      if (line.includes('then') || line.includes('do') || line === 'else') {
        indentLevel++;
      }
    }
  }

  return shellCode;
};