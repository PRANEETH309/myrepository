import { useState, useEffect } from 'react';
import { CodeEditor } from '../components/CodeEditor';
import { LanguageSelector } from '../components/LanguageSelector';
import { Header } from '../components/Header';
import { convertToJava, convertToPython } from '../utils/codeConverter';
import { convertToShell } from '../utils/shellConverter';
import { ArrowRight, Clipboard, Check } from 'lucide-react';

export const CodeConverterPage = () => {
  const [inputCode, setInputCode] = useState<string>('// Enter your C code here\n#include <stdio.h>\n\nint main() {\n    printf("Hello, World!");\n    return 0;\n}');
  const [outputLanguage, setOutputLanguage] = useState<string>('python');
  const [outputCode, setOutputCode] = useState<string>('');
  const [isEditing, setIsEditing] = useState<boolean>(false);
  const [copied, setCopied] = useState<boolean>(false);
  
  const getConvertedCode = () => {
    switch (outputLanguage) {
      case 'python':
        return convertToPython(inputCode);
      case 'java':
        return convertToJava(inputCode);
      case 'shell':
        return convertToShell(inputCode);
      default:
        return '';
    }
  };

  const handleCopy = async () => {
    await navigator.clipboard.writeText(outputCode);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  useEffect(() => {
    setOutputCode(getConvertedCode());
    setIsEditing(false);
  }, [inputCode, outputLanguage]);

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 text-white">
      <Header />
      
      <main className="container mx-auto px-4 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-gray-800/50 p-4 rounded-t-lg border-b border-gray-700">
              <h2 className="text-xl font-semibold">Input (C Code)</h2>
              <div className="flex items-center gap-2">
                <span className="text-sm text-gray-400">C</span>
              </div>
            </div>
            <div className="rounded-b-lg overflow-hidden border border-gray-700 shadow-lg">
              <CodeEditor
                value={inputCode}
                onChange={(value) => setInputCode(value || '')}
                language="c"
              />
            </div>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-center justify-between bg-gray-800/50 p-4 rounded-t-lg border-b border-gray-700">
              <h2 className="text-xl font-semibold">Output</h2>
              <div className="flex items-center gap-4">
                <button
                  onClick={handleCopy}
                  className="px-3 py-1 rounded bg-gray-700 hover:bg-gray-600 transition-colors flex items-center gap-2"
                >
                  {copied ? (
                    <>
                      <Check className="w-4 h-4" />
                      <span>Copied!</span>
                    </>
                  ) : (
                    <>
                      <Clipboard className="w-4 h-4" />
                      <span>Copy</span>
                    </>
                  )}
                </button>
                <button
                  onClick={() => setIsEditing(!isEditing)}
                  className="px-3 py-1 rounded bg-blue-600 hover:bg-blue-700 transition-colors"
                >
                  {isEditing ? 'View Only' : 'Edit'}
                </button>
                <ArrowRight className="w-5 h-5 text-gray-400" />
                <LanguageSelector
                  selectedLanguage={outputLanguage}
                  onChange={setOutputLanguage}
                />
              </div>
            </div>
            <div className="rounded-b-lg overflow-hidden border border-gray-700 shadow-lg">
              <CodeEditor
                value={outputCode}
                onChange={(value) => isEditing && setOutputCode(value || '')}
                language={outputLanguage}
                readOnly={!isEditing}
              />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};