import { Editor, loader } from '@monaco-editor/react';
import { FC, useEffect, useState } from 'react';

// Configure Monaco loader with fallback CDN
loader.config({
  paths: {
    vs: 'https://cdnjs.cloudflare.com/ajax/libs/monaco-editor/0.45.0/min/vs'
  },
  'vs/nls': {
    availableLanguages: {
      '*': ''
    }
  }
});

interface CodeEditorProps {
  value: string;
  onChange: (value: string | undefined) => void;
  language: string;
  readOnly?: boolean;
}

export const CodeEditor: FC<CodeEditorProps> = ({ value, onChange, language, readOnly = false }) => {
  const [isLoaded, setIsLoaded] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loader.init()
      .then(() => setIsLoaded(true))
      .catch(err => {
        console.error('Monaco initialization failed:', err);
        setError('Failed to load editor. Please refresh the page.');
      });
  }, []);

  if (error) {
    return (
      <div className="h-[400px] bg-gray-800 rounded-lg flex items-center justify-center text-red-400 p-4">
        {error}
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className="h-[400px] bg-gray-800 rounded-lg flex items-center justify-center text-gray-400">
        Loading editor...
      </div>
    );
  }

  return (
    <Editor
      height="400px"
      defaultLanguage={language}
      value={value}
      onChange={onChange}
      theme="vs-dark"
      options={{
        minimap: { enabled: false },
        fontSize: 14,
        readOnly,
        scrollBeyondLastLine: false,
        automaticLayout: true,
        tabSize: 2,
        wordWrap: 'on',
        formatOnPaste: true,
        formatOnType: true,
        renderWhitespace: 'selection',
        quickSuggestions: true,
        folding: true
      }}
      beforeMount={(monaco) => {
        monaco.editor.defineTheme('vs-dark', {
          base: 'vs-dark',
          inherit: true,
          rules: [],
          colors: {
            'editor.background': '#1f2937'
          }
        });
      }}
    />
  );
};