import { ReactNode } from 'react';
import { Code2 } from 'lucide-react';

interface AuthLayoutProps {
  children: ReactNode;
  title: string;
  subtitle: string;
}

export const AuthLayout = ({ children, title, subtitle }: AuthLayoutProps) => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 flex items-center justify-center px-4">
      <div className="max-w-md w-full space-y-8 bg-gray-800 p-8 rounded-xl shadow-2xl">
        <div className="flex flex-col items-center">
          <Code2 className="w-12 h-12 text-blue-500" />
          <h2 className="mt-6 text-3xl font-bold text-white text-center">
            {title}
          </h2>
          <p className="mt-2 text-gray-400 text-center">
            {subtitle}
          </p>
        </div>
        {children}
      </div>
    </div>
  );
};