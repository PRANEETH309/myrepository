import React from 'react';
import { Code2} from 'lucide-react';

export const Header: React.FC = () => {
  return (
    <header className="border-b border-gray-800 bg-gray-900/50 backdrop-blur-sm">
      <div className="container mx-auto px-4 py-6">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Code2 className="w-10 h-10 text-blue-500" />
            <div>
              <h1 className="text-2xl font-bold bg-gradient-to-r from-blue-500 to-cyan-500 bg-clip-text text-transparent">
                Syntax Shift
              </h1>
              <p className="text-sm text-gray-400">Transform your code seamlessly</p>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}